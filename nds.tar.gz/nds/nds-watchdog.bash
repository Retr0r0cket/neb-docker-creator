#!/bin/bash
# Debriefing lobby timeout value in seconds, if this value is exceeded, NDS service will be restarted.
TIMEOUT="330"
# If watchdog has encountered a recoverable error, it will restart after waiting for the specified value in seconds.
RESTART="30"

# Don't touch these variables.
NDSSERVICE="$1"
NDSLOG="$2"
FIRSTSTART="true"

function recoverable_error {
  echo "WARN: Stopping watchdog in $RESTART seconds"
  echo "INFO: Watchdog should be auto restarted by systemd"
  sleep $RESTART
  exit 0
}

# Main loop
while true; do
  if systemctl -q list-unit-files $NDSSERVICE >> /dev/null; then
    echo "INFO: NDS service file $NDSSERVICE found."
  else
    echo "FATAL ERROR: NDS service file $NDSSERVICE not found."
    exit 1
  fi

  if systemctl -q is-active $NDSSERVICE >> /dev/null; then
    echo "INFO: NDS service is active."
    if [ $FIRSTSTART = "true" ]; then
      FIRSTSTART="false"
      echo "WARN: NDS service was activated before watchdog, restarting NDS service..."
      systemctl -q restart $NDSSERVICE >> /dev/null
    fi
  else
    if [ $FIRSTSTART = "true" ]; then
      FIRSTSTART="false"
      echo "INFO: NDS service is inactive, first time trying to activate..."
    else
      echo "WARN: NDS service is inactive, trying to activate..."
    fi

    if systemctl -q start $NDSSERVICE >> /dev/null; then
      echo "INFO: NDS service has been activated."
    else
      echo "ERROR: NDS service could not been activated."
      recoverable_error
    fi
  fi

  # Wait some time for the NDS service to start
  sleep 1s

  if test -r $NDSLOG; then
    echo "INFO: NDS logfile $NDSLOG found and readable."
  else
    echo "ERROR: NDS logfile $NDSLOG not found or not readable."
    recoverable_error
  fi

  # Initialize runtime files
  mkdir -p /run/nds-watchdog && \
  touch /run/nds-watchdog/debriefing && \
  echo "false" > /run/nds-watchdog/debriefing && \
  touch /run/nds-watchdog/lobby && \
  echo "false" > /run/nds-watchdog/lobby && \
  echo "INFO: Watching NDS service..." || (echo "FATAL ERROR: Unable to initialize runtime files"; exit 2)

  # Watcher for debriefing
  echo $(tail -f $NDSLOG | \
         grep -q -m 1 -F "GameManager Game.SkirmishGameManager being replaced by Game.SkirmishDebriefingLobbyController" && \
         echo "true") > /run/nds-watchdog/debriefing &

  # Control loop for debriefing watcher
  while [ $(cat /run/nds-watchdog/debriefing) = "false" ] && systemctl -q is-active $NDSSERVICE >> /dev/null; do
    sleep 1s
  done

  # Test one more time for active NDS service, when active it means the skirmish has ended and debriefing has started.
  if systemctl -q is-active $NDSSERVICE >> /dev/null; then
    echo "INFO: Skirmish ended - Debriefing started"
  else
    echo "ERROR: NDS service is inactive"
    recoverable_error
  fi

  # Watcher for lobby
  echo $(tail -f $NDSLOG | \
         grep -q -m 1 -F "GameManager Game.SkirmishDebriefingLobbyController being replaced by Game.SkirmishLobbyManager" && \
         echo "true") > /run/nds-watchdog/lobby &

  # Control loop for lobby watcher
  SECONDS="0"
  while [ $(cat /run/nds-watchdog/lobby) = "false" ] && [ $SECONDS -lt $TIMEOUT ] && systemctl -q is-active $NDSSERVICE >> /dev/null; do
    sleep 1s
  done

  # Test one more time for active NDS service, if inactive it means the server crashed while in debriefing.
  if systemctl -q is-active $NDSSERVICE >> /dev/null; then
    echo "INFO: Debriefing lasted for $SECONDS seconds"
  else
    echo "ERROR: NDS service is inactive"
    recoverable_error
  fi

  if [ $SECONDS -ge $TIMEOUT ]; then
    echo "WARN: Debriefing timeout of $TIMEOUT seconds reached."
    echo "ERROR: NDS stuck in debriefing, stopping NDS service..."
    systemctl -q stop $NDSSERVICE >> /dev/null
    recoverable_error
  else
      echo "INFO: Lobby started"
  fi
done

echo "FATAL PROGRAM ERROR: Terminating"
exit -1
